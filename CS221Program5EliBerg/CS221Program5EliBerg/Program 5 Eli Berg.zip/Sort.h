#pragma once
class Sort
{
protected:
	bool showWork;

public:
	Sort();
	~Sort();

	void SetShowWork(bool showWork);
	bool GetShowWork();
	virtual void Sorted(int array[], int len) = 0; //implement in derived classes
	virtual void Print(int array[], int len) = 0; //implement in derived classes
};

