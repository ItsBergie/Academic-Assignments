#include "sort.h"
#include <iostream>
#pragma once

class Sort1 : public Sort
{

public:
    Sort1();
    ~Sort1();

    void Sorted(int array[], int len);
    void Print(int array[], int len);
};

