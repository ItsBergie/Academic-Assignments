#include "sort.h"
#include <iostream>
#pragma once

class Sort2 : public Sort
{
private:
    void merge(int array[], int left, int mid, int right);
    void mergeSort(int array[], int begin, int end);

public:
    Sort2();
    ~Sort2();

    void Sorted(int array[], int len);
    void Print(int array[], int len);
};
