#include "sort.h"
#include <iostream>
#pragma once

class Sort3 : public Sort
{
private:
    void quickSort(int array[], int start, int end);
    int partition(int array[], int low, int high);
    /*void quickSort(int arr[], int start, int end);
    int partition(int arr[], int start, int end);*/

public:
    Sort3();
    ~Sort3();

    void Sorted(int array[], int len);
    void Print(int array[], int len);
};
